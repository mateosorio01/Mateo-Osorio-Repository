function showMoreInfo() {
    var moonInfo = document.getElementById("moon-info");
    var satelliteInfo = document.getElementById("satellite-info");
    var button = document.getElementById("show-more-button");

    moonInfo.innerHTML += "<p>The Moon's diameter is about 3,474 kilometers and it has a surface area of about 38 million square kilometers.</p>";
    satelliteInfo.innerHTML += "<p>Artificial satellites are used for various purposes including communication, weather forecasting, navigation, and scientific research.</p>";

    button.disabled = true;
}