/*
    Student Name: Mateo Osorio Delhonte
    File Name: script.js
    Date: 04/12/2024
*/

//jQuery for hero image to consume the header window space

$(document).ready(function(){
    $('.hero').height($(window).height());
});